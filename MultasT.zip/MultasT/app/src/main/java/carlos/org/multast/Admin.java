package carlos.org.multast;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Carlos Orantes on 17/07/2016.
 */
public class Admin extends SQLiteOpenHelper {
    public Admin (Context context, String nombre, SQLiteDatabase.CursorFactory factory, int version){
        super(context, nombre, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table nomtabla(placa integer primary key, nombre text, causa text, monto integer, pla integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exist nomtabla");
        db.execSQL("create table nomtabla(placa integer primary key, nombre text, causa text, monto integer, pla integer)");
    }
}
